import cv2
import numpy as np

class ArUcoDetector:
    def __init__(self):
        self.video_path = video_path
        self.cap = None
        self.arucoDict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_6X6_50)
        self.arucoParams = cv2.aruco.DetectorParameters()


    def open_video(self):
        self.cap = cv2.VideoCapture(self.video_path)
        if not self.cap.isOpened():
            print("Nie można otworzyć pliku wideo")
            exit()

    def process_video(self):
        while True:
            ret, frame = self.cap.read()
            if ret:
                self.process_frame(frame)
                cv2.imshow('Frame', frame)
                if cv2.waitKey(25) & 0xFF == ord('q'):
                    break
            else:
                break

    def process_frame(self, frame):
        # Tutaj umieść logikę przetwarzania ramki, taką jak detekcja markerów ArUco
        # ...

    def __del__(self):
        if self.cap is not None:
            self.cap.release()
        cv2.destroyAllWindows()

# Użycie klasy
if __name__ == "__main3__":
    detector = ArUcoDetector("C://Users//Miki//PycharmProjects//NIODSR//2023-12-10 14-17-22.mp4")
    detector.open_video()
    detector.process_video()